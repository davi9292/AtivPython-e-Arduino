# davi de assis fabricio, vinicius queiroz e thomas gabriel
estoque_atual = {
    "canetas": 150,
    "cadernos": 95,
    "lápis": 200,
    "borrachas": 30,
    "régua": 45,
    "cola": 60,
    "tesoura": 25,
    "marcador": 75,
    "clips": 120,
    "grampos": 40
}

movimentacoes_dia = [
    ("canetas", "saída", 25),
    ("cadernos", "entrada", 10),
    ("borrachas", "saída", 50),
    ("régua", "saída", 20),
    ("cola", "entrada", 15),
    ("tesoura", "saída", 10),
    ("marcador", "entrada", 25),
    ("clips", "saída", 30),
    ("grampos", "saída", 15),
    ("lápis", "saída", 45),
    ("canetas", "entrada", 50),
    ("cadernos", "saída", 35),
    ("borrachas", "entrada", 40),
    ("régua", "entrada", 30),
    ("cola", "saída", 25)
]

def mostrar_estoque(estoque):
    print("\nESTOQUE ATUAL:")
    for produto, quantidade in sorted(estoque.items()):
        print(f"{produto.capitalize():<12} | {quantidade:>4} unidades")

def adicionar_movimentacao_manual():
    movimentacoes_manuais = []
    
    print("\nADICIONE SUAS MOVIMENTAÇÕES:")
    print("Digite 'sair' para terminar")
    
    while True:
        produto = input("\nProduto: ").strip().lower()
        if produto == 'sair':
            break
            
        tipo = input("Tipo (entrada/saída): ").strip().lower()
        if tipo not in ['entrada', 'saída']:
            print("Tipo inválido!")
            continue
            
        try:
            quantidade = int(input("Quantidade: "))
            if quantidade <= 0:
                print("Quantidade deve ser maior que zero!")
                continue
        except:
            print("Digite um número valido!")
            continue
            
        movimentacoes_manuais.append((produto, tipo, quantidade))
        print(f"Movimentação adicionada")
        
        continuar = input("\nAdicionar outra? (s/n): ").strip().lower()
        if continuar != 's':
            break
    
    return movimentacoes_manuais

def processar_movimentacoes(estoque, movimentacoes):
    for produto, tipo, quantidade in movimentacoes:
        if tipo == "entrada":
            if produto in estoque:
                estoque[produto] += quantidade
            else:
                estoque[produto] = quantidade
            print(f"✓ Entrada: +{quantidade} {produto}")
        elif tipo == "saída":
            if produto in estoque:
                if estoque[produto] >= quantidade:
                    estoque[produto] -= quantidade
                    print(f"✓ Saída: -{quantidade} {produto}")
                else:
                    print(f"Estoque insuficiente de {produto}")

def identificar_produtos_baixo_estoque(estoque):
    produtos_baixo_estoque = []
    for produto, quantidade in estoque.items():
        if quantidade <= 50:
            produtos_baixo_estoque.append((produto, quantidade))
    return produtos_baixo_estoque

def gerar_relatorio(estoque, produtos_baixo_estoque):
    print("\n" + "="*50)
    print("RELATÓRIO FINAL")
    
    print("\nESTOQUE ATUALIZADO:")
    print("-" * 30)
    for produto, quantidade in sorted(estoque.items()):
        status = "!" if quantidade <= 50 else "✓"
        print(f"{status} {produto.capitalize():<12} | {quantidade:>4} unidades")
    
    print("\nPRODUTOS PRA REPOR:")
    print("-" * 30)
    if produtos_baixo_estoque:
        for produto, quantidade in sorted(produtos_baixo_estoque):
            print(f"{produto.capitalize():<12} | {quantidade:>4} unidades")
    else:
        print("Nenhum produto precisa repor.")

def main():
    print("SISTEMA DE CONTROLE DE ESTOQUE")
    
    mostrar_estoque(estoque_atual)
    
    print("\nMOVIMENTAÇÕES DO DIA:")
    processar_movimentacoes(estoque_atual, movimentacoes_dia)
    
    mostrar_estoque(estoque_atual)
    
    movimentacoes_usuario = adicionar_movimentacao_manual()
    
    if movimentacoes_usuario:
        print("\nSUAS MOVIMENTAÇÕES:")
        processar_movimentacoes(estoque_atual, movimentacoes_usuario)
    
    produtos_reposicao = identificar_produtos_baixo_estoque(estoque_atual)
    
    gerar_relatorio(estoque_atual, produtos_reposicao)

if __name__ == "__main__":
    main()